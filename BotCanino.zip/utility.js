const { Presence } = require("@whiskeysockets/baileys");
const fs = require("fs");
const { estado, marcarModificado } = require('./estado');

const STATES_FILE = "estados.json";

// Función para leer los estados desde el archivo JSON
function readStates() {
    // Devuelve referencia al objeto de estado en memoria cargado desde estado.js
    return estado;
}


// Función para escribir los estados en el archivo JSON
function writeStates(_s) {
    // Marcamos el estado como modificado para que estado.js lo guarde en el siguiente ciclo
    marcarModificado();
}


// Función para obtener el estado de un usuario
function getUserState(jid) {
    const states = readStates();
    // Estado inicial por defecto: INICIO, con userData vacío, lastActivityTimestamp y reminderCount
    return states[jid] || { state: "INFORMACION_INICIAL", userData: {}, lastActivityTimestamp: Date.now(), reminderCount: 0 };
}

// Función para actualizar el estado de un usuario
function updateUserState(jid, newState, newUserData = {}) {
    // Actualiza el estado en memoria y marca para guardado diferido
    // Preservar reminderCount si el estado no cambia
    const currentState = estado[jid];
    const preserveReminderCount = currentState && currentState.state === newState;
    
    estado[jid] = {
        state: newState,
        userData: newUserData,
        lastActivityTimestamp: Date.now(),
        reminderCount: preserveReminderCount ? (currentState.reminderCount || 0) : 0
    };
    marcarModificado();
}


// Función para actualizar solo la información del recordatorio de un usuario
function updateUserReminderInfo(jid, reminderCount) {
    if (estado[jid]) {
        estado[jid].reminderCount = reminderCount;
        // CLAVE: Actualizar el timestamp para forzar el delay antes del siguiente recordatorio
        estado[jid].lastActivityTimestamp = Date.now(); 
        marcarModificado();
    }
}


// Función para eliminar el estado de un usuario
function deleteUserState(jid) {
    const states = readStates();
    delete states[jid];
    writeStates(states);
}

// Función para obtener todos los estados de los usuarios
function getAllUserStates() {
    return readStates();
}

/**
 * Simula una respuesta humana con la secuencia de presencia:
 * En línea (2s) -> Escribiendo (variable) -> Enviar Mensaje -> En línea (2s) -> Pausado.
 * @param {object} sock - La instancia del socket de Baileys.
 * @param {string} jid - El JID del destinatario.
 * @param {string} responseText - El texto de la respuesta a enviar.
 * @param {function} sendResponseCallback - Función de callback para enviar el mensaje (debe ser async).
 */
async function simulateHumanResponse(sock, jid, responseText, sendResponseCallback) {
    // 1. Mostrar que está en línea por 2 segundos
    await sock.sendPresenceUpdate("available", jid);
    await delay(2000);

    // 2. Mostrar que está escribiendo (duración variable según la longitud del mensaje)
    await sock.sendPresenceUpdate("composing", jid);
    // 50ms por caracter, mínimo 1s, máximo 5s
    const typingDuration = Math.min(Math.max(responseText.length * 50, 1000), 5000);
    await delay(typingDuration);

    // 3. Enviar el mensaje
    await sendResponseCallback(jid, responseText);

    // 4. Mostrar que está en línea por 2 segundos adicionales
    await sock.sendPresenceUpdate("available", jid);
    await delay(2000);

    // 5. MANTENER el estado 'available' para asegurar los dos cheques grises.
    // await sock.sendPresenceUpdate("unavailable", jid); // Línea comentada para mantener el estado en línea
}

module.exports = {
    simulateHumanResponse,
    getUserState,
    updateUserState,
    updateUserReminderInfo,
    deleteUserState,
    readStates,
    getAllUserStates,
    delay,
};


// Función para normalizar texto (eliminar tildes y convertir a minúsculas)
function normalizeText(text) {
    return text.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
}

module.exports.normalizeText = normalizeText;



// Función para introducir un retardo
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports.delay = delay;




/**
 * Función de "Humanización" para simular desconexiones periódicas.
 * Esto evita que el bot parezca estar SIEMPRE en línea, haciéndolo más "humano".
 * 
 * @param {object} sock - La instancia del socket de Baileys.
 * @param {function} delay - La función de retardo (delay) de utility.js.
 * @param {number} intervalSeconds - El intervalo de tiempo en segundos entre cada ciclo (ej. 60 segundos).
 * @param {number} offlineDurationSeconds - La duración en segundos que el bot estará "unavailable" (ej. 5 segundos).
 */
async function startHumanizationHeartbeat(sock, delay, intervalSeconds = 60, offlineDurationSeconds = 5) {
    const intervalMs = intervalSeconds * 1000;
    const offlineDurationMs = offlineDurationSeconds * 1000;

    setInterval(async () => {
        try {
            // 1. Simular desconexión (unavailable)
            await sock.sendPresenceUpdate("unavailable");
            console.log(`[Humanización] Bot en estado 'unavailable' por ${offlineDurationSeconds} segundos.`);

            // 2. Esperar la duración de la desconexión
            await delay(offlineDurationMs);

            // 3. Volver al estado "available" para asegurar los dos cheques grises
            await sock.sendPresenceUpdate("available");
            console.log("[Humanización] Bot ha regresado al estado 'available'.");

        } catch (error) {
            console.error("[Humanización] Error en el ciclo de Heartbeat:", error);
        }
    }, intervalMs);
}

module.exports.startHumanizationHeartbeat = startHumanizationHeartbeat;


function getAllUsers() {
    return estado;
}


// Exports añadidos por modificación para trabajar en memoria
module.exports.updateUserState = updateUserState;
module.exports.updateUserReminderInfo = updateUserReminderInfo;
module.exports.getAllUsers = getAllUsers;
module.exports.readStates = readStates;
module.exports.writeStates = writeStates;
