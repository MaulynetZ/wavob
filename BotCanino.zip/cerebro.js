const utility = require("./utility");
const path = require('path');
const fs = require('fs');
const { estado, marcarModificado, guardarEstado } = require('./estado');
const { OPCIONES_POR_ESTADO } = require("./opciones_por_estado");
const { jidNormalizedUser, downloadMediaMessage } = require("@whiskeysockets/baileys");
const { REMINDERS_POR_ESTADO } = require("./recordatorios_por_estado");
const { MENSAJE_1, MENSAJE_2, MENSAJE_3 } = require("./mensajes_iniciales");

// Bloqueo en memoria para evitar el procesamiento concurrente de mensajes del mismo usuario
const processingJids = new Set();
const { getAudioDurationInSeconds } = require('get-audio-duration');

let whatsappSock;
const ADMIN_JID = "258347232145579@lid";
const globalResponses = require("./respuestasglobales.js");

function findGlobalResponse(message) {
    const normalizedMessage = utility.normalizeText(message);

    for (const globalResponse of globalResponses) {
        for (const keyword of globalResponse.keywords) {
            const normalizedKeyword = utility.normalizeText(keyword);
            if (normalizedMessage.includes(normalizedKeyword)) {
                return globalResponse.response;
            }
        }
    }
    return null;
}

async function sendResponse(jid, text) {
    await whatsappSock.sendMessage(jid, { text: text });
}

async function sendVoiceNoteResponse(jid) {
    const audioPath = path.join(__dirname, 'nota_voz', 'respuesta_voz.opus');

    if (fs.existsSync(audioPath)) {
        try {
            const duration = await getAudioDurationInSeconds(audioPath);
            const recordingDuration = Math.max(duration * 1000, 1000);

            await whatsappSock.sendPresenceUpdate("recording", jid);
            await utility.delay(recordingDuration);

            await whatsappSock.sendMessage(jid, {
                audio: { url: audioPath },
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true 
            });
            console.log(`Nota de voz de respuesta enviada a ${jid} después de simular ${duration.toFixed(2)}s de grabación.`);

            await whatsappSock.sendPresenceUpdate("available", jid);

        } catch (error) {
            console.error("Error al procesar o enviar la nota de voz de respuesta:", error);
            await whatsappSock.sendPresenceUpdate("available", jid);
        }
    } else {
        console.error(`ERROR: Archivo de nota de voz no encontrado en ${audioPath}`);
    }
}

async function handleMessage(jid, messageBody, isMedia, messageObject) {
    // 1. Bloqueo en memoria: Si ya estamos procesando un mensaje de este JID, ignorar.
    if (processingJids.has(jid)) {
        console.log(`[BLOQUEO] Mensaje ignorado para ${jid} (ya en procesamiento).`);
        return;
    }
    processingJids.add(jid); // Marcar como en procesamiento

    try {
        let userState = utility.getUserState(jid);
        let currentState = userState.state;
        let userData = userState.userData;

        // Se elimina la condición `currentState !== "VENTA_TERMINADA"` para que siempre se actualice el timestamp
        utility.updateUserState(jid, currentState, userData);
        userState = utility.getUserState(jid);
        currentState = userState.state;
        userData = userState.userData;

        console.log(`User ${jid} is in state: ${currentState}, message: ${messageBody}, isMedia: ${isMedia}`);

        if (!messageBody && currentState !== "ESPERANDO_PAGO") {
            console.log(`[FILTRO] Mensaje vacío ignorado en estado ${currentState}.`);
            return;
        }

        let responseText = "";
        let nextState = currentState;
        let newUserData = userData;

        const globalResponse = findGlobalResponse(messageBody);

        if (globalResponse) {
            const opciones = OPCIONES_POR_ESTADO[currentState] || OPCIONES_POR_ESTADO["DEFAULT"];
            responseText = `${globalResponse}\n\n*Recuerda las opciones para este paso:*\n${opciones}`;
        } else {
            switch (currentState) {
                case "INFORMACION_INICIAL":
                    if (userData.hasReceivedWelcome) {
                        console.log(`[FILTRO RÁFAGA] Mensaje ignorado para ${jid} en INFORMACION_INICIAL (ya recibió bienvenida).`);
                        return;
                    }

                    await utility.simulateHumanResponse(whatsappSock, jid, MENSAJE_1, sendResponse);
                    await utility.delay(3000);

                    await utility.simulateHumanResponse(whatsappSock, jid, MENSAJE_2, sendResponse);
                    await utility.delay(3000);

                    await utility.simulateHumanResponse(whatsappSock, jid, MENSAJE_3, sendResponse);

                    newUserData = { ...userData, hasReceivedWelcome: true };
                    nextState = "ESPERANDO_RESPUESTA_INICIAL";
                    utility.updateUserState(jid, nextState, newUserData);
                    
                    return;

                case "ESPERANDO_RESPUESTA_INICIAL":
                    if (messageBody === "1") {
                        responseText = `🚨 ¡OFERTA ESPECIAL! 🚨\n\nEl *LIBRO DIGITAL EN PDF* (incluyendo los 2 bonos) tiene un valor de: *$7.000* único pago.\n\nEsta oferta es válida solo por **48 horas**.\n\nPuedes pagar por cualquiera de estos medios:\n\n💸 Nequi: 3218557201\n💳 Daviplata: 3334002468\n💰 Tranfiya: 3334002468\n🔑 Llave: 72432684\n\n📦 Envíame el comprobante y recibirás tu *LIBRO DIGITAL EN PDF* al instante 📲`;
                        nextState = "ESPERANDO_PAGO";
                    } else if (messageBody === "2") {
                        responseText = `¡Hola! 😊 Por supuesto, estoy aquí para resolver tus dudas. Cuéntame, ¿en qué te puedo ayudar? ¡Es un placer atenderte! 🙌✨`;
                        nextState = "ASISTENTE_VIRTUAL";
                    } else {
                        responseText = `Opción no válida. ${OPCIONES_POR_ESTADO["ESPERANDO_RESPUESTA_INICIAL"]}`;
                        nextState = "ESPERANDO_RESPUESTA_INICIAL";
                    }
                    break;

                // Los estados ESPERANDO_DETALLES_EBOOK y VIENDO_DETALLES_EBOOK se eliminan.
                // La lógica de ASISTENTE_VIRTUAL se mantiene.

                case "ESPERANDO_PAGO":
                    if (isMedia) {
                        try {
                            const buffer = await downloadMediaMessage(messageObject, 'buffer');
                            const filename = `${jid.split('@')[0]}_${Date.now()}.jpeg`;
                            const savePath = path.join(__dirname, 'comprobantes', filename);
                            fs.writeFileSync(savePath, buffer);
                            
                            console.log(`Comprobante guardado en: ${savePath}`);

                            const caption = `🚨 NUEVO COMPROBANTE DE PAGO 🚨\n\nJID del remitente: ${jid}`;
                            await whatsappSock.sendMessage(ADMIN_JID, {
                                image: { url: savePath },
                                caption: caption
                            });

                            const phoneNumber = jid.split('@')[0];
                            const okCommand = `ok ${phoneNumber}`;
                            const noCommand = `no ${phoneNumber}`;

                            await whatsappSock.sendMessage(ADMIN_JID, { text: okCommand });
                            await whatsappSock.sendMessage(ADMIN_JID, { text: noCommand });

                            responseText = `¡Gracias por enviar tu comprobante! Estamos verificando tu pago. Te notificaremos apenas tengamos una respuesta.`;
                            nextState = "ESPERANDO_VALIDACION_PAGO";

                        } catch (error) {
                            console.error("Error al procesar el comprobante de pago:", error);
                            responseText = `Lo siento, hubo un error al procesar tu comprobante. Por favor, inténtalo de nuevo o contacta a soporte.`;
                            nextState = "ESPERANDO_PAGO";
                        }
                    } else {
                        if (!globalResponse) {
                            responseText = `Opción no válida. ${OPCIONES_POR_ESTADO[currentState]}`;
                        }
                    }
                    break;

                case "ESPERANDO_VALIDACION_PAGO":
                    if (!globalResponse) {
                        responseText = OPCIONES_POR_ESTADO[currentState];
                    }
                    break;

                case "ASISTENTE_VIRTUAL":
                    if (messageBody.toLowerCase() === "comprar") {
                        responseText = `🚨 ¡OFERTA ESPECIAL! 🚨\n\nEl *LIBRO DIGITAL EN PDF* (incluyendo los 2 bonos) tiene un valor de: *$7.000* único pago.\n\nEsta oferta es válida solo por **48 horas**.\n\nPuedes pagar por cualquiera de estos medios:\n\n💸 Nequi: 3218557201\n💳 Daviplata: 3334002468\n💰 Tranfiya: 3334002468\n🔑 Llave: 72432684\n\n📦 Envíame el comprobante y recibirás tu *LIBRO DIGITAL EN PDF* al instante 📲`;
                        nextState = "ESPERANDO_PAGO";
                    } else {
                        responseText = `Lo siento, no entendí tu pregunta. ¿Podrías formularla de otra manera? 🤔\n\nTambién puedes escribir *COMPRAR* si deseas proceder con la compra.`;
                    }
                    break;

                case "VENTA_TERMINADA":
                    if (globalResponse) {
                        responseText = globalResponse;
                    } else {
                        responseText = "¡Gracias por tu compra! Tu proceso ha finalizado. Si tienes alguna duda, puedes escribirnos.";
                    }
                    nextState = "VENTA_TERMINADA";
                    break;

                default:
                    responseText = OPCIONES_POR_ESTADO["DEFAULT"];
                    nextState = "INFORMACION_INICIAL";
                    break;
            }
        }

        if (responseText) {
            await utility.simulateHumanResponse(whatsappSock, jid, responseText, sendResponse);
        }

        utility.updateUserState(jid, nextState, newUserData);
    
    } catch (error) {
        console.error(`Error en handleMessage para ${jid}:`, error);
    } finally {
        processingJids.delete(jid);
    }
}

async function handleAdminMessage(msg) {
    const messageBody = msg.message?.extendedTextMessage?.text || msg.message?.conversation || "";
    const adminJid = jidNormalizedUser(msg.key.remoteJid);

    if (adminJid !== ADMIN_JID) {
        return;
    }

    console.log(`Mensaje de administrador (${adminJid}): ${messageBody}`);

    let match;
    let targetJid;

    match = messageBody.match(/^ok\s+([\d@\.:]+)/i);
    if (match) {
        const targetJidInput = match[1];
        let targetJid;

        if (!targetJidInput.includes('@')) {
            if (targetJidInput.length > 15) { 
                targetJid = `${targetJidInput}@lid`;
            } else {
                targetJid = `${targetJidInput}@s.whatsapp.net`;
            }
        } else {
            targetJid = targetJidInput;
        }
        
        let userState = utility.getUserState(targetJid);

        if (userState.state !== "ESPERANDO_VALIDACION_PAGO" && !targetJidInput.includes('@')) {
            const alternateSuffix = targetJid.endsWith('@s.whatsapp.net') ? '@lid' : '@s.whatsapp.net';
            const alternateJid = `${targetJidInput}${alternateSuffix}`;
            
            const alternateUserState = utility.getUserState(alternateJid);
            if (alternateUserState.state === "ESPERANDO_VALIDACION_PAGO") {
                targetJid = alternateJid;
                userState = alternateUserState;
            }
        }

        if (userState.state === "ESPERANDO_VALIDACION_PAGO") {
            try {
                const pdfsDir = path.join(__dirname, 'pdfs');
                const pdfFiles = fs.readdirSync(pdfsDir).filter(file => file.endsWith('.pdf'));

                // 1. Enviar mensaje de pago aprobado con emojis
                const msgAprobado = "¡Felicidades! 🎉 Tu pago ha sido aprobado con éxito. En breve recibirás tu *LIBRO DIGITAL EN PDF* y los bonos.";
                await whatsappSock.sendMessage(targetJid, { text: msgAprobado });

                // 2. Esperar 2 segundos
                await utility.delay(2000);

                // 3. Enviar los PDFs
                for (const file of pdfFiles) {
                    const filePath = path.join(pdfsDir, file);
                    await whatsappSock.sendMessage(targetJid, {
                        document: { url: filePath },
                        mimetype: 'application/pdf',
                        fileName: file
                    });
                }

                // 4. Esperar 2 segundos
                await utility.delay(2000);
                
                // 5. Enviar mensaje de agradecimiento con emojis
                const msgGracias = "¡Gracias por tu compra! 🙏 Esperamos que disfrutes tu nuevo material. Si tienes alguna duda, no dudes en contactarnos. ✨";
                await whatsappSock.sendMessage(targetJid, { text: msgGracias });
                utility.updateUserState(targetJid, "VENTA_TERMINADA");
                console.log(`Usuario ${targetJid} movido al estado VENTA_TERMINADA tras pago exitoso.`);
                
                await whatsappSock.sendMessage(ADMIN_JID, { text: `✅ ÉXITO: Los PDFs fueron enviados correctamente a ${targetJid}.` });

            } catch (error) {
                console.error(`Error al enviar PDFs o borrar estado para ${targetJid}:`, error);
                await whatsappSock.sendMessage(ADMIN_JID, { text: `❌ ERROR: No se pudieron enviar los PDFs a ${targetJid}. El usuario no fue notificado del éxito. Revisa la consola.` });
            }
        } else {
             await whatsappSock.sendMessage(ADMIN_JID, { text: `⚠️ AVISO: El usuario ${targetJid} no está en "ESPERANDO_VALIDACION_PAGO". Estado actual: ${userState.state}` });
        }
        return;
    }

    match = messageBody.match(/^no\s+([\d@\.:]+)/i);
    if (match) {
        const targetJidInput = match[1];
        let targetJid;
        if (!targetJidInput.includes('@')) {
            if (targetJidInput.length > 15) { 
                targetJid = `${targetJidInput}@lid`;
            } else {
                targetJid = `${targetJidInput}@s.whatsapp.net`;
            }
        } else {
            targetJid = targetJidInput;
        }
        
        let userState = utility.getUserState(targetJid);
        if (userState.state !== "ESPERANDO_VALIDACION_PAGO" && !targetJidInput.includes('@')) {
            const alternateSuffix = targetJid.endsWith('@s.whatsapp.net') ? '@lid' : '@s.whatsapp.net';
            const alternateJid = `${targetJidInput}${alternateSuffix}`;
            
            const alternateUserState = utility.getUserState(alternateJid);
            if (alternateUserState.state === "ESPERANDO_VALIDACION_PAGO") {
                targetJid = alternateJid;
                userState = alternateUserState;
            }
        }
        if (userState.state === "ESPERANDO_VALIDACION_PAGO") {
            try {
                const message = "Lo sentimos, el comprobante de pago no pudo ser confirmado. Por favor, revisa que la imagen sea clara y que el monto sea correcto. Vuelve a enviarlo o contacta a un asesor.";
                await whatsappSock.sendMessage(targetJid, { text: message });
                utility.updateUserState(targetJid, "ESPERANDO_PAGO", userState.userData);
                console.log(`Usuario ${targetJid} regresado al estado ESPERANDO_PAGO.`);
                
                await whatsappSock.sendMessage(ADMIN_JID, { text: `✅ ACCIÓN COMPLETADA: Se notificó a ${targetJid} que su pago fue rechazado y se regresó al estado de espera.` });

            } catch (error) {
                console.error(`Error al notificar pago fallido a ${targetJid}:`, error);
                await whatsappSock.sendMessage(ADMIN_JID, { text: `❌ ERROR: No se pudo notificar el pago fallido a ${targetJid}. Revisa la consola.` });
            }
        } else {
            await whatsappSock.sendMessage(ADMIN_JID, { text: `⚠️ AVISO: El usuario ${targetJid} no está en "ESPERANDO_VALIDACION_PAGO". Estado actual: ${userState.state}` });
        }
        return;
    }

    if (messageBody.toLowerCase() === "dell terminados") {
        try {
            const states = utility.readStates();
            let deletedCount = 0;
            const jidsToDelete = [];

            for (const jid in states) {
                if (states[jid].state === "VENTA_TERMINADA") {
                    jidsToDelete.push(jid);
                }
            }

            for (const jid of jidsToDelete) {
                utility.deleteUserState(jid);
                deletedCount++;
            }

            if (deletedCount > 0) {
                await whatsappSock.sendMessage(ADMIN_JID, { text: `${deletedCount} usuarios del estado venta terminada eliminados con éxito.` });
            } else {
                await whatsappSock.sendMessage(ADMIN_JID, { text: "No se encontraron usuarios en el estado venta terminada para eliminar." });
            }
        } catch (error) {
            console.error("Error al eliminar usuarios del estado VENTA_TERMINADA:", error);
            await whatsappSock.sendMessage(ADMIN_JID, { text: "ERROR: No se pudieron eliminar usuarios del estado venta terminada." });
        }
        return;
    }
}

async function checkReminders() {
    const allUsers = utility.getAllUsers();
    const now = Date.now();

    for (const jid in allUsers) {
        const userState = allUsers[jid];
        const currentState = userState.state;
        const lastActivityTimestamp = userState.lastActivityTimestamp || Date.now();
        const reminderCount = userState.reminderCount || 0;

        const reminderConfig = REMINDERS_POR_ESTADO[currentState];

        if (reminderConfig && reminderCount < reminderConfig.maxReminders) {
            const delay = reminderConfig.delay;
            const nextReminderTime = lastActivityTimestamp + delay;

            if (now >= nextReminderTime) {
                let reminderMessage;
                let isLastReminder = false;

                if (reminderCount === reminderConfig.maxReminders - 1) {
                    // Es el último recordatorio (el 6to)
                    isLastReminder = true;
                    reminderMessage = `🚨 ¡ÚLTIMA OPORTUNIDAD! 🚨 La promoción de *$7.000 COP* termina **HOY a las 11:59 pm**.\n\nDespués de esta hora, el *Libro Digital de Recetas para Mascotas* costará *$49.909 COP*.\n\n¡No pierdas esta oportunidad!`;
                } else {
                    reminderMessage = reminderConfig.messages[reminderCount];
                }

                await utility.simulateHumanResponse(whatsappSock, jid, reminderMessage, sendResponse);

                const newReminderCount = reminderCount + 1;
                utility.updateUserReminderInfo(jid, newReminderCount);

                console.log(`[RECORDATORIO] Enviado recordatorio ${newReminderCount}/${reminderConfig.maxReminders} a ${jid} en estado ${currentState}.`);

                if (isLastReminder) {
                    // Después del último recordatorio, no se enviarán más
                    console.log(`[RECORDATORIO] Último recordatorio enviado a ${jid}.`);
                }
            }
        }
    }
}

function init(sock) {
    whatsappSock = sock;
    console.log("Cerebro initialized with WhatsApp sock.");

    utility.startHumanizationHeartbeat(whatsappSock, utility.delay, 60, 5);

    setInterval(() => checkReminders(), 2 * 60 * 1000); // Verificar cada 1 minuto

    whatsappSock.ev.on("messages.upsert", async ({ messages, type }) => {

    // --- Comando administrador: copiamj (case-insensitive) ---
    try {
        for (const m of messages) {
            const from = m.key && m.key.remoteJid ? m.key.remoteJid : null;
            const text = (m.message && m.message.conversation) ? m.message.conversation : (m.message && m.message.extendedTextMessage && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : '');
            if (from && text && from === ADMIN_JID) {
                const normalized = text.trim().toLowerCase();
                if (normalized === 'copiamj') {
                    guardarEstado();
                    try { await whatsappSock.sendMessage(from, { text: '✅ Copia del estado guardada correctamente.' }); } catch(e){ console.error('Error enviando confirmación a admin:', e); }
                }
            }
        }
    } catch(e) {
        console.error('Error manejando comando copiamj:', e);
    }

    
        if (type === "notify") {
            for (const msg of messages) {
                if (!msg.key.fromMe && msg.key.remoteJid !== "status@broadcast") {
                    const jid = jidNormalizedUser(msg.key.remoteJid);
                    const isImage = msg.message?.imageMessage !== undefined || msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage !== undefined;
                    const isVoiceNote = msg.message?.audioMessage?.mimetype === 'audio/ogg; codecs=opus';
                    const isMedia = isImage || isVoiceNote;
                    let messageBody = msg.message?.extendedTextMessage?.text || msg.message?.conversation || "";
                    if (isImage && !messageBody) {
                        messageBody = msg.message?.imageMessage?.caption || "";
                    }

                    if (jid === ADMIN_JID) {
                        await handleAdminMessage(msg);
                    } else {
                        const randomDelay = Math.floor(Math.random() * (5000 - 2000 + 1)) + 2000;
                        await utility.delay(randomDelay);
                        await whatsappSock.readMessages([msg.key]);

                        if (isVoiceNote) {
                            await sendVoiceNoteResponse(jid);
                            continue;
                        }
                        
                        await handleMessage(jid, messageBody, isMedia, msg);
                    }
                }
            }
        }
    });
}

module.exports = {
    init,
    checkReminders
};
