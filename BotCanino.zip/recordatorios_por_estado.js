const REMINDERS_POR_ESTADO = {
    "ESPERANDO_RESPUESTA_INICIAL": {
        delay:  10 * 60 * 1000, // 3 minutos (180000 ms)
        maxReminders: 6,
        messages: [
            "¡Hola de nuevo! 👋 Vi que te interesó la *OFERTA ESPECIAL* del Libro Digital.\n\nRecuerda que la promoción de *$7.000* es solo por **48 horas**. ¿Tienes alguna duda antes de decidirte?\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
            "¡No te quedes sin tu *Libro Digital*! 📚✨\n\nCon él, aprenderás a preparar recetas saludables para tu peludo. ¡Es una inversión que se paga sola!\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
            "¡Última oportunidad! ⏳ La promoción de *$7.000* está por terminar.\n\nRecuerda que incluye 2 bonos exclusivos que te ayudarán a emprender.\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
            "¡Aprovecha el precio especial! 💸 Por solo *$7.000*, obtienes el conocimiento para cuidar la salud de tu peludo.\n\n¿Te ayudo a ver los métodos de pago?\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
            "¡Solo quedan unas horas! 🚨 No dejes pasar esta oportunidad única.\n\nSi tienes dudas, escribe *2* para hablar con un consultor.\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
            "placeholder_for_last_reminder" // Este será reemplazado dinámicamente en cerebro.js
        ]
    },
    "ESPERANDO_PAGO": {
        delay:  10 * 60 * 1000, // 3 minutos (180000 ms)
        maxReminders: 6,
        messages: [
            "¡Hola! 👋 Veo que ya tienes los datos de pago. ¿Tuviste algún problema para enviar el comprobante?\n\nRecuerda que tu *Libro Digital* te espera. ¡Envía la foto de tu pago para recibirlo al instante!",
            "¡No olvides enviar tu comprobante! 📸\n\nEstamos listos para enviarte tu *Libro Digital* y los bonos exclusivos.\n\nSi necesitas los datos de pago de nuevo, puedes solicitarlos.",
            "¡Tu cupo está reservado! 🔒 Pero necesitamos tu comprobante para liberarlo.\n\nRecuerda que la promoción es por tiempo limitado. ¡Asegura tu compra ahora!",
            "¡Estamos a la espera de tu comprobante! ⏳\n\nSi tienes alguna duda sobre los métodos de pago, no dudes en preguntar.",
            "¡Solo un paso más! 👣 Envía tu comprobante de pago para finalizar la compra y empezar a disfrutar de las recetas para tu peludo.",
            "placeholder_for_last_reminder" // Este será reemplazado dinámicamente en cerebro.js
        ]
    },
    "ESPERANDO_VALIDACION_PAGO": {
        delay:  10 * 60 * 1000, // 3 minutos (180000 ms)
        maxReminders: 6,
        messages: [
            "¡Hola! 👋 Estamos validando tu pago. Te avisaremos apenas tengamos una respuesta. Si tienes alguna duda, puedes escribirnos.",
            "¡Tu pago está en proceso! ⏳ Estamos verificando tu comprobante. En breve tendrás noticias nuestras.",
            "¡Casi listo! ✨ Tu *Libro Digital* está a un paso de ser tuyo. Estamos validando tu pago. ¡Gracias por tu paciencia!",
            "Seguimos validando tu pago.",
            "¡Solo un momento más! 🙏 Estamos finalizando la validación de tu pago. Te notificaremos pronto.",
            "placeholder_for_last_reminder" // Este será reemplazado dinámicamente en cerebro.js
        ]
    },
    "ASISTENTE_VIRTUAL": {
        delay:  10 * 60 * 1000, // 3 minutos (180000 ms)
        maxReminders: 6,
        messages: [
            "¡Hola! 👋 ¿Pudiste resolver tus dudas sobre la *OFERTA ESPECIAL*?\n\nSi estás listo para comprar el libro por *$7.000*, escribe *COMPRAR* y te envío los datos de pago. 💸",
            "¡No te vayas sin tu libro! 📚 Recuerda que con esta inversión aprenderás a cuidar la salud de tu peludo.\n\nEscribe *COMPRAR* para proceder con tu pedido. ✨",
            "¡La promoción de *$7.000* es por tiempo limitado! ⏳\n\n¿Tienes más preguntas o estás listo para comprar? Escribe *COMPRAR* para continuar. 💸",
            "¡Aprovecha esta oportunidad única! 🚨 El *Libro Digital* incluye 2 bonos exclusivos.\n\nEscribe *COMPRAR* cuando estés listo. 📲",
            "¡Última oportunidad para aprovechar el precio especial de *$7.000*! 💸\n\nSi tienes dudas, pregúntame. Si estás listo, escribe *COMPRAR*.",
            "placeholder_for_last_reminder" // Este será reemplazado dinámicamente en cerebro.js
        ]
    }
};

module.exports = {
    REMINDERS_POR_ESTADO
};
