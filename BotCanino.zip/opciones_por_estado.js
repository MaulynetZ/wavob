const OPCIONES_POR_ESTADO = {
    "INFORMACION_INICIAL": "Por favor, espera la secuencia de mensajes de bienvenida.",
    "ESPERANDO_RESPUESTA_INICIAL": "Por favor, responde con el número de la opción que prefieras:\n\n1️⃣ Ver los métodos de pago 💸\n2️⃣ Hablar con un consultor 👩‍💼",
    "ESPERANDO_PAGO": "Por favor, debe enviar el comprobante de pago (una imagen).",
    "ESPERANDO_VALIDACION_PAGO": "Estamos validando tu pago. Por favor, espera la confirmación.",
    "ASISTENTE_VIRTUAL": "Escribe *COMPRAR* para volver a ver los métodos de pago.",
    "VENTA_TERMINADA": "¡Gracias por tu compra! Tu proceso ha finalizado.",
    "DEFAULT": "Ha ocurrido un error con tu estado. Reiniciando conversación. Por favor, escribe *informacion*."
};

module.exports = {
    OPCIONES_POR_ESTADO
};
