const MENSAJE_1 = `👋 ¡Hola! Bienvenido/a 😊  
Soy tu asistente en la cocina para mascotas.  
Estás a punto de descubrir cómo preparar *más de 100 recetas saludables y deliciosas* para tu peludo, con ingredientes que tienes en casa 🐶🐱✨`;

const MENSAJE_2 = `🔥 *¡PROMO DISPONIBLE SOLO POR 48 HORAS!* 🔥  
Obtén el 📘 *Ebook: 100 Recetas para mi Peludo* + *2 BONOS EXCLUSIVOS:*  
	
🎁 *BONO 1:* 10 Postres Peludos (Recetas de postres saludables).  
🧼 *BONO 2:* Alimentos Prohibidos para tu Mascota (Guía de seguridad alimentaria).  
	
✨ Todo el paquete por solo *$7.000 pesitos (único pago)*  
⏰ *Oferta válida solo por 48 horas.*`;

const MENSAJE_3 = `✨ ¿Qué deseas hacer ahora?  
	
👉 *Escribe y enviame el número de la opción que prefieras:*  
	
🟢 Envia el número 1️⃣ para *ver los métodos de pago 💸*  
🟢 Envia el número 2️⃣ para *hablar con un consultor 👩‍💼*`;

module.exports = { MENSAJE_1, MENSAJE_2, MENSAJE_3 };