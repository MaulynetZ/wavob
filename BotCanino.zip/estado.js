// ================================================
// 💾 Módulo de manejo de estado en memoria
// ================================================
// Carga 'estados.json' al iniciar, mantiene el objeto en memoria,
// permite marcar modificaciones y guardar en disco cada 2 horas,
// y guarda al recibir señales de terminación (SIGINT, SIGTERM, exit).

const fs = require('fs');
const path = require('path');

const RUTA_ESTADO = path.join(__dirname, 'estados.json');

// Objeto de estado en memoria
let estado = {};

// Bandera para detectar cambios
let modificado = false;

// Cargar estado inicial (si existe)
function cargarEstado() {
  try {
    if (fs.existsSync(RUTA_ESTADO)) {
      const data = fs.readFileSync(RUTA_ESTADO, 'utf8');
      estado = JSON.parse(data);
      console.log('✅ Estado cargado desde disco');
    } else {
      estado = {};
      console.log('ℹ️ estados.json no existe — iniciando con estado vacío en memoria');
    }
  } catch (err) {
    console.warn('⚠️ Error cargando estados.json, iniciando con estado vacío:', err);
    estado = {};
  }
}

// Guardar estado en disco (sincrónico, intencional para consistencia en señales)
function guardarEstado() {
  try {
    fs.writeFileSync(RUTA_ESTADO, JSON.stringify(estado, null, 2), 'utf8');
    console.log('💾 Estado guardado en disco');
  } catch (err) {
    console.error('❌ Error al guardar el estado:', err);
  }
}

// Marcar que hubo modificaciones en memoria
function marcarModificado() {
  modificado = true;
}

// Auto-save cada 2 horas (solo si hubo cambios)
setInterval(() => {
  if (modificado) {
    guardarEstado();
    modificado = false;
  }
}, 2 * 60 * 60 * 1000); // 2 horas

// Guardar antes de terminar el proceso
function handleExit(signal) {
  try {
    console.log('\\n🧹 Señal recibida (' + signal + ') — guardando estado antes de salir...');
    guardarEstado();
  } catch (err) {
    console.error('Error guardando estado en exit:', err);
  }
}

// Escuchar señales comunes
process.on('SIGINT', () => { handleExit('SIGINT'); process.exit(0); });
process.on('SIGTERM', () => { handleExit('SIGTERM'); process.exit(0); });
process.on('exit', (code) => { try { guardarEstado(); console.log('Proceso saliendo, código', code); } catch(e){} });

// Inicializar carga de estado al require
cargarEstado();

module.exports = { estado, marcarModificado, guardarEstado };
