module.exports = [
  {
    "category": "Precio",
    "keywords": ["cuanto cuesta", "precio", "valor", "costo", "cuanto vale"],
    "response": "El libro digital 'Maestro Perfumista' tiene un valor de *$15.000* pesos colombianos. Es un pago único."
  },
  {
    "category": "Bonos",
    "keywords": ["bonos", "regalos", "bonificaciones", "beneficios extra"],
    "response": "¡Sí! Con la compra del ebook 'Maestro Perfumista' recibes 2 bonos exclusivos:\n1. Otro ebook para aprender a hacer jabones.\n2. Una lista detallada de proveedores, adaptada a la ciudad donde vive el cliente. ¡Estos bonos se entregan después de la compra del ebook principal!"
  },
  {
    "category": "Descuentos",
    "keywords": ["descuento", "oferta", "promocion", "rebaja", "codigo descuento"],
    "response": "Actualmente no hay descuentos disponibles, pero el valor de $15.000 es una inversión mínima para todo el conocimiento que obtendrás."
  },
  {
    "category": "Entrega",
    "keywords": ["entrega ebook", "recibir ebook", "cuando llega", "enviar ebook", "mandan ebook"],
    "response": "El ebook 'Maestro Perfumista' se entrega *inmediatamente* por WhatsApp una vez confirmado el pago."
  },
  {
    "category": "Formato",
    "keywords": ["formato del ebook", "ebook", "como leer ebook"],
    "response": "El ebook 'Maestro Perfumista' está en formato *PDF*, ideal para leer en tu celular, tablet, computador o incluso imprimirlo."
  },
  {
    "category": "Empresa",
    "keywords": ["quienes son", "empresa", "academia", "hubicados"],
    "response": "Somos 'Academia Emprende Ya', una empresa virtual fundada en enero de 2001. Nos dedicamos a ayudar a las personas a emprender de manera fácil y práctica."
  },
  {
    "category": "Horario",
    "keywords": ["horario atencion", "atienden", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo", "festivo", "festivos"],
    "response": "Nuestro horario de atención es:\n*Lunes a Viernes*: 8 AM a 10 PM\n*Sábados, Domingos y Festivos*: 8 AM a 6 PM.\nSiempre respondemos lo más pronto posible dentro de estos horarios."
  },
  {
    "category": "PagoMetodos",
    "keywords": ["metodos pago", "formas de pago", "pago", "como pagar", "quiero pagar", "pagar con", "nequi", "daviplata", "transfiya", "llave"],
    "response": "Puedes realizar tu pago a través de *Nequi*, *Daviplata*, *Transfiya* o *Llave*. ¡Elige el que te sea más cómodo!"
  },
  {
    "category": "ContenidoEbook",
    "keywords": ["contenido del ebook", "que trae el ebook", "aprendo con el ebook", "enseña el ebook", "de que trata el  ebook"],
    "response": "El ebook 'Maestro Perfumista' está diseñado para que aprendas a crear perfumes de forma rápida y práctica. No necesitas materiales costosos ni fórmulas complicadas. ¡Es ideal para emprender fácilmente!"
  },
  {
    "category": "Experiencia",
    "keywords": ["experiencia", "principiante", "novato", "facil de  aprender", "sin conocimientos"],
    "response": "¡No necesitas experiencia previa! El ebook está diseñado para que cualquier persona, incluso sin conocimientos, pueda aprender a crear perfumes desde cero de manera sencilla."
  },
  {
    "category": "Materiales",
    "keywords": ["materias primas", "ingredientes", "donde comprar materiales", "proveedores"],
    "response": "El ebook te enseña a usar ingredientes fáciles de conseguir y, además, incluye un bono con una lista detallada de proveedores en Colombia."
  },
  {
    "category": "Confiabilidad",
    "keywords": ["confiable", "seguro", "estafa", "legal", "garantia", "confianza"],
    "response": "¡Absolutamente confiable! Somos 'Academia Emprende Ya', una empresa establecida desde enero de 2001. Nuestro compromiso es brindarte conocimiento de valor para tu emprendimiento. Miles de estudiantes satisfechos avalan nuestra trayectoria y la calidad de nuestros materiales. Tu inversión está segura y garantizada con nosotros."
  }
];