const OPCIONES_POR_ESTADO = {
    "INICIO": "Por favor, escribe *informacion* para comenzar.",
    "INFORMACION_INICIAL": "Por favor, responde con el número que mejor te describa:\n\n1️⃣ Nunca he hecho perfumes \n2️⃣ Ya intenté hacer perfumes antes \n3️⃣ Me interesa pero tengo dudas 🤔",
    "ESPERANDO_DETALLES_EBOOK": "Por favor, escribe *PDF* o *CURSO* para ver los detalles.",
    "VIENDO_DETALLES_EBOOK": "Por favor, responde con el numero:\n\n1️⃣ Sí, quiero comprar \n2️⃣ Tengo una duda",
    "ESPERANDO_PAGO": "Por favor, debe enviar el comprobante de pago (una imagen).",
    "ESPERANDO_VALIDACION_PAGO": "Estamos validando tu pago. Por favor, espera la confirmación.",
    "ASISTENTE_VIRTUAL": "Escribe *COMPRAR* para volver a ver los métodos de pago.",
    "VENTA_TERMINADA": "¡Gracias por tu compra! Tu proceso ha finalizado.",
    "DEFAULT": "Ha ocurrido un error con tu estado. Reiniciando conversación. Por favor, escribe *informacion*."
};

module.exports = {
    OPCIONES_POR_ESTADO
};

