const utility = require("./utility");
const path = require('path');
const fs = require('fs');
const { OPCIONES_POR_ESTADO } = require("./opciones_por_estado");
const { jidNormalizedUser, downloadMediaMessage } = require("@whiskeysockets/baileys");
const { REMINDERS_POR_ESTADO } = require("./recordatorios_por_estado");
const { getAudioDurationInSeconds } = require('get-audio-duration');

let whatsappSock;
const ADMIN_JID = "258347232145579@lid";
const globalResponses = require("./respuestasglobales.js");

function findGlobalResponse(message) {
    const normalizedMessage = utility.normalizeText(message);

    for (const globalResponse of globalResponses) {
        for (const keyword of globalResponse.keywords) {
            const normalizedKeyword = utility.normalizeText(keyword);
            if (normalizedMessage.includes(normalizedKeyword)) {
                return globalResponse.response;
            }
        }
    }
    return null;
}

async function sendResponse(jid, text) {
    await whatsappSock.sendMessage(jid, { text: text });
}

async function sendVoiceNoteResponse(jid) {
    const audioPath = path.join(__dirname, 'nota_voz', 'respuesta_voz.opus');

    if (fs.existsSync(audioPath)) {
        try {
            // 1. Obtener la duración del audio para simular la grabación
            const duration = await getAudioDurationInSeconds(audioPath);
            const recordingDuration = Math.max(duration * 1000, 1000); // Mínimo 1 segundo de grabación

            // 2. Simular la grabación (Presence: recording)
            await whatsappSock.sendPresenceUpdate("recording", jid);
            await utility.delay(recordingDuration);

            // 3. Enviar la nota de voz
            await whatsappSock.sendMessage(jid, {
                audio: { url: audioPath },
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true 
            });
            console.log(`Nota de voz de respuesta enviada a ${jid} después de simular ${duration.toFixed(2)}s de grabación.`);

            // 4. Volver al estado 'available'
            await whatsappSock.sendPresenceUpdate("available", jid);

        } catch (error) {
            console.error("Error al procesar o enviar la nota de voz de respuesta:", error);
            // Asegurar que la presencia vuelva a 'available' en caso de error
            await whatsappSock.sendPresenceUpdate("available", jid);
        }
    } else {
        console.error(`ERROR: Archivo de nota de voz no encontrado en ${audioPath}`);
    }
}

async function handleMessage(jid, messageBody, isMedia, messageObject) {
    let userState = utility.getUserState(jid);
    let currentState = userState.state;
    let userData = userState.userData;

    if (currentState !== "VENTA_TERMINADA") {
        utility.updateUserState(jid, currentState, userData);
        userState = utility.getUserState(jid);
        currentState = userState.state;
        userData = userState.userData;
    }

    console.log(`User ${jid} is in state: ${currentState}, message: ${messageBody}, isMedia: ${isMedia}`);

    let responseText = "";
    let nextState = currentState;
    let newUserData = userData;

    const globalResponse = findGlobalResponse(messageBody);

    if (globalResponse) {
        const opciones = OPCIONES_POR_ESTADO[currentState] || OPCIONES_POR_ESTADO["DEFAULT"];
        responseText = `${globalResponse}\n\n*Recuerda las opciones para este paso:*\n${opciones}`;
    } else {
        switch (currentState) {
            case "INICIO":
                responseText = `✨ ¡Hola! Gracias por escribir 😊\n\n📚✨ ¡Lanzamos nuestro *LIBRO DIGITAL* en *PDF* !\nAprende a crear perfumes desde cero 💐 sin experiencia previa y desde la comodidad de tu hogar.\nIncluye paso a paso, recetas exclusivas 🧪 y tips para emprender 🛍️.\n\n✅ Todo en un archivo *PDF* que puedes leer desde tu celular en el computador 📱 o imprimir.\n\n🎁 Incluye 2 BONOS EXCLUSIVOS:\n\n1️⃣ Lista de proveedores en Colombia por ciudad\n2️⃣ Guía para hacer jabones espumosos\n\nEste Libro digital en *PDF* ya ha ayudado a más de 200 personas en Colombia 🇨🇴\n\nResponde con el número que mejor te describa:\n\n1️⃣ Nunca he hecho perfumes \n2️⃣ Ya intenté hacer perfumes antes \n3️⃣ Me interesa pero tengo dudas `;
                nextState = "INFORMACION_INICIAL";
                break;

            case "INFORMACION_INICIAL":
                if (messageBody === "1") {
                    responseText = `🌸 ¡Qué emoción! 😊\n\nEste *LIBRO DIGITAL EN PDF* es perfecto si estás empezando desde cero:\n\n✅ No necesitas experiencia \n✅ Explicaciones paso a paso \n✅ Materiales fáciles de conseguir \n✅ Fórmulas inspiradas en perfumes famosos\n\n📝 ¿Quieres que te muestre TODO lo que incluye el *LIBRO* ? \nSolo escribe: *PDF*`;
                    nextState = "ESPERANDO_DETALLES_EBOOK";
                } else if (messageBody === "2") {
                    responseText = `😮‍💨 ¡Te entiendo! No siempre es fácil lograr que un perfume dure o huela bien...\n\nEste *LIBRO DIGITAL EN PDF* te ayuda a:\n\n✅ Corregir errores comunes \n✅ Usar fijadores y proporciones reales \n✅ listado de proveedores de confianza \n✅ Aprender a vender desde casa \n✅técnicas para vender por Internet \n✅hacer tu misma/o las etiquetas \n\n📝 ¿Quieres ver todo lo que contiene el *LIBRO DIGITAL EN PDF *? \nEscribe: *PDF*`;
                    nextState = "ESPERANDO_DETALLES_EBOOK";
                } else if (messageBody === "3") {
                    responseText = `🤔 ¡Y es normal tener dudas al principio!\n\nEste *CURSO* no solo enseña a hacer perfumes… también te guía para emprender paso a paso:\n\n✅ Dónde comprar materiales en cada ciudad de colombia\n✅ Cómo mezclar correctamente \n✅ Cómo hacer etiquetas sin ser diseñador\n✅ Tips para vender por Internet o físicamente \n\n📝 ¿Quieres ver TODO lo que incluye el *PDF* ? \nEscribe: *CURSO*`;
                    nextState = "ESPERANDO_DETALLES_EBOOK";
                } else {
                    responseText = `Opción no válida. ${OPCIONES_POR_ESTADO[currentState]}`;
                }
                break;

            case "ESPERANDO_DETALLES_EBOOK":
                if (messageBody.toLowerCase() === "pdf" || messageBody.toLowerCase() === "curso") {
                    responseText = `💥Aquí tienes la info completa sobre el libro digital “Maestro Perfumista” 📘✨\n\nEste material está diseñado para enseñarte a crear perfumes profesionales desde casa, sin necesidad de saber química ni tener experiencia.\n\nMuch@s creen que emprender en perfumería es complicado, pero la verdad es que:\n❌ No necesitas un laboratorio\n❌ No tienes que invertir millones\n❌ Y no necesitas ser experta para empezar\n\n💡 Con este libro vas a aprender a: ✅ Crear perfumes desde cero, con esencias o aceites naturales\n✅ Hacer perfumes con feromonas para atraer de forma natural 😍\n✅ Usar ingredientes fáciles de conseguir (¡te damos lista de proveedores confiables!)\n✅ Construir tu propia marca, diseñar tu catálogo y vender desde casa\n✅ Aplicar fórmulas exactas paso a paso sin errores\n✅ Evitar los errores comunes que hacen que un perfume dure poco o huela mal\n\n🎁 Incluye BONOS GRATIS:\n📍 Lista de proveedores en tu ciudad\n🧼 Guía para hacer jabones espumosos y aumentar tu catálogo\n\n🔥 Es ideal si estás buscando: ✔️ Un ingreso extra sin salir de casa\n✔️ Algo creativo, relajante y rentable\n✔️ Diferenciarte creando productos únicos y de alto valor✨ Diversifica tu negocio con soluciones efectivas, seguras y amigables con el planeta. 🧴💧\n\n¿Quieres comprarlo ahora?\n\nResponde con el numero:\n1️⃣ Sí, quiero comprar \n2️⃣ Hablar con un asesor `;
                    nextState = "VIENDO_DETALLES_EBOOK";
                } else {
                    responseText = `Opción no válida. ${OPCIONES_POR_ESTADO[currentState]}`;
                }
                break;

            case "VIENDO_DETALLES_EBOOK":
                if (messageBody === "1") {
                    responseText = `💸 El * LIBRO DIGITAL EN PDF* tiene un valor de : *$15.000* único pago\n\nPuedes pagar por cualquiera de estos medios:\n\n💸 Nequi: 3218557201\n💳 Daviplata: 3334002468\n💰 Tranfiya: 3334002468\n🔑 Llave: 72432684\n\n📦 Envíame el comprobante y recibirás tu *LIBRO DIGITAL EN PDF* al instante 📲`;
                    nextState = "ESPERANDO_PAGO";
                } else if (messageBody === "2") {
                    responseText = `¡Hola! 😊 Por supuesto, estoy aquí para resolver tus dudas. Cuéntame, ¿en qué te puedo ayudar? ¡Es un placer atenderte! 🙌✨`;
                    nextState = "ASISTENTE_VIRTUAL";
                } else {
                    responseText = `Opción no válida. ${OPCIONES_POR_ESTADO[currentState]}`;
                }
                break;

            case "ESPERANDO_PAGO":
                if (isMedia) {
                    try {
                        const buffer = await downloadMediaMessage(messageObject, 'buffer');
                        const filename = `${jid.split('@')[0]}_${Date.now()}.jpeg`;
                        const savePath = path.join(__dirname, 'comprobantes', filename);
                        fs.writeFileSync(savePath, buffer);
                        
                        console.log(`Comprobante guardado en: ${savePath}`);

                        const caption = `NUEVO COMPROBANTE DE PAGO\n\nJID del remitente: ${jid}`;
                        await whatsappSock.sendMessage(ADMIN_JID, {
                            image: { url: savePath },
                            caption: caption
                        });

                        responseText = `¡Gracias por enviar tu comprobante! Estamos verificando tu pago. Te notificaremos apenas tengamos una respuesta.`;
                        nextState = "ESPERANDO_VALIDACION_PAGO";

                    } catch (error) {
                        console.error("Error al procesar el comprobante de pago:", error);
                        responseText = `Lo siento, hubo un error al procesar tu comprobante. Por favor, inténtalo de nuevo o contacta a soporte.`;
                        nextState = "ESPERANDO_PAGO";
                    }
                } else {
                    if (!globalResponse) {
                        responseText = `Opción no válida. ${OPCIONES_POR_ESTADO[currentState]}`;
                    }
                }
                break;

            case "ESPERANDO_VALIDACION_PAGO":
                if (!globalResponse) {
                    responseText = OPCIONES_POR_ESTADO[currentState];
                }
                break;

            case "ASISTENTE_VIRTUAL":
                const assistantGlobalResponse = findGlobalResponse(messageBody);
                
                if (assistantGlobalResponse) {
                    responseText = `${assistantGlobalResponse}\n\n¿Deseas proceder con la compra?\n\nEscribe *COMPRAR* para ver los métodos de pago.`;
                    nextState = "ASISTENTE_VIRTUAL";
                } else if (messageBody.toLowerCase() === "comprar") {
                    responseText = `💸 El * LIBRO DIGITAL EN PDF* tiene un valor de : *$15.000* único pago\n\nPuedes pagar por cualquiera de estos medios:\n\n💸 Nequi: 3218557201\n💳 Daviplata: 3334002468\n💰 Tranfiya: 3334002468\n🔑 Llave: 72432684\n\n📦 Envíame el comprobante y recibirás tu *LIBRO DIGITAL EN PDF* al instante 📲`;
                    nextState = "ESPERANDO_PAGO";
                } else {
                    responseText = `Lo siento, no entendí tu pregunta. ¿Podrías formularla de otra manera? 🤔\n\nTambién puedes escribir *COMPRAR* si deseas proceder con la compra.`;
                    nextState = "ASISTENTE_VIRTUAL";
                }
                break;

            case "VENTA_TERMINADA":
                if (globalResponse) {
                    responseText = globalResponse;
                } else {
                    responseText = "Lo siento, tu consulta no pudo ser procesada. Si necesitas ayuda, por favor contacta al administrador.";
                }
                nextState = "VENTA_TERMINADA";
                break;
            default:
                responseText = OPCIONES_POR_ESTADO["DEFAULT"];
                nextState = "INICIO";
                break;
        }
    }

    await utility.simulateHumanResponse(whatsappSock, jid, responseText, sendResponse);

    if (nextState !== currentState) {
        utility.updateUserState(jid, nextState, newUserData);
    }
}

async function handleAdminMessage(msg) {
    const messageBody = msg.message?.extendedTextMessage?.text || msg.message?.conversation || "";
    const adminJid = jidNormalizedUser(msg.key.remoteJid);

    if (adminJid !== ADMIN_JID) {
        return;
    }

    console.log(`Mensaje de administrador (${adminJid}): ${messageBody}`);

    let match;
    let targetJid;

    match = messageBody.match(/^ok\s+([\d@\.:]+)/i);
    if (match) {
        const targetJidInput = match[1];
        let targetJid;

        if (!targetJidInput.includes('@')) {
            if (targetJidInput.length > 15) { 
                targetJid = `${targetJidInput}@lid`;
            } else {
                targetJid = `${targetJidInput}@s.whatsapp.net`;
            }
        } else {
            targetJid = targetJidInput;
        }
        
        let userState = utility.getUserState(targetJid);

        if (userState.state !== "ESPERANDO_VALIDACION_PAGO" && !targetJidInput.includes('@')) {
            const alternateSuffix = targetJid.endsWith('@s.whatsapp.net') ? '@lid' : '@s.whatsapp.net';
            const alternateJid = `${targetJidInput}${alternateSuffix}`;
            
            const alternateUserState = utility.getUserState(alternateJid);

            if (alternateUserState.state === "ESPERANDO_VALIDACION_PAGO") {
                targetJid = alternateJid;
                userState = alternateUserState;
            }
        }

        if (userState.state === "ESPERANDO_VALIDACION_PAGO") {
            try {
                await whatsappSock.sendMessage(targetJid, { text: "¡Tu pago ha sido aprobado! En breve recibirás tus archivos. 🎉" });

                const pdfsDir = path.join(__dirname, 'pdfs');
                const pdfFiles = fs.readdirSync(pdfsDir).filter(file => file.endsWith('.pdf'));

                for (const file of pdfFiles) {
                    const filePath = path.join(pdfsDir, file);
                    await whatsappSock.sendMessage(targetJid, {
                        document: { url: filePath },
                        mimetype: 'application/pdf',
                        fileName: file
                    });
                }
                
                await whatsappSock.sendMessage(targetJid, { text: "¡Gracias por tu compra! Esperamos que disfrutes el contenido. 😊" });
                utility.updateUserState(targetJid, "VENTA_TERMINADA");
                console.log(`Usuario ${targetJid} movido al estado VENTA_TERMINADA tras pago exitoso.`);
                
                await whatsappSock.sendMessage(ADMIN_JID, { text: `✅ ÉXITO: Los PDFs fueron enviados correctamente a ${targetJid}.` });

            } catch (error) {
                console.error(`Error al enviar PDFs o borrar estado para ${targetJid}:`, error);
                await whatsappSock.sendMessage(ADMIN_JID, { text: `❌ ERROR: No se pudieron enviar los PDFs a ${targetJid}. El usuario no fue notificado del éxito. Revisa la consola.` });
            }
        } else {
             await whatsappSock.sendMessage(ADMIN_JID, { text: `⚠️ AVISO: El usuario ${targetJid} no está en "ESPERANDO_VALIDACION_PAGO". Estado actual: ${userState.state}` });
        }
        return;
    }
    
    match = messageBody.match(/^no\s+([\d@\.:]+)/i);
    if (match) {
        const targetJidInput = match[1];
        let targetJid;
        if (!targetJidInput.includes('@')) {
            if (targetJidInput.length > 15) { 
                targetJid = `${targetJidInput}@lid`;
            } else {
                targetJid = `${targetJidInput}@s.whatsapp.net`;
            }
        } else {
            targetJid = targetJidInput;
        }
        
        let userState = utility.getUserState(targetJid);
        if (userState.state !== "ESPERANDO_VALIDACION_PAGO" && !targetJidInput.includes('@')) {
            const alternateSuffix = targetJid.endsWith('@s.whatsapp.net') ? '@lid' : '@s.whatsapp.net';
            const alternateJid = `${targetJidInput}${alternateSuffix}`;
            
            const alternateUserState = utility.getUserState(alternateJid);
            if (alternateUserState.state === "ESPERANDO_VALIDACION_PAGO") {
                targetJid = alternateJid;
                userState = alternateUserState;
            }
        }
        if (userState.state === "ESPERANDO_VALIDACION_PAGO") {
            try {
                const message = "Lo sentimos, el comprobante de pago no pudo ser confirmado. Por favor, vuelve a enviar el comprobante de pago correcto.";
                await whatsappSock.sendMessage(targetJid, { text: message });
                utility.updateUserState(targetJid, "ESPERANDO_PAGO", userState.userData);
                console.log(`Usuario ${targetJid} regresado al estado ESPERANDO_PAGO.`);
                
                await whatsappSock.sendMessage(ADMIN_JID, { text: `✅ ACCIÓN COMPLETADA: Se notificó a ${targetJid} que su pago fue rechazado y se regresó al estado de espera.` });

            } catch (error) {
                console.error(`Error al notificar pago fallido a ${targetJid}:`, error);
                await whatsappSock.sendMessage(ADMIN_JID, { text: `❌ ERROR: No se pudo notificar el pago fallido a ${targetJid}. Revisa la consola.` });
            }
        } else {
            await whatsappSock.sendMessage(ADMIN_JID, { text: `⚠️ AVISO: El usuario ${targetJid} no está en "ESPERANDO_VALIDACION_PAGO". Estado actual: ${userState.state}` });
        }
        return;
    }

    if (messageBody.toLowerCase() === "dell terminados") {
        try {
            const states = utility.readStates();
            let deletedCount = 0;
            const jidsToDelete = [];

            for (const jid in states) {
                if (states[jid].state === "VENTA_TERMINADA") {
                    jidsToDelete.push(jid);
                }
            }

            for (const jid of jidsToDelete) {
                utility.deleteUserState(jid);
                deletedCount++;
            }

            if (deletedCount > 0) {
                await whatsappSock.sendMessage(ADMIN_JID, { text: `${deletedCount} usuarios del estado venta terminada eliminados con éxito.` });
            } else {
                await whatsappSock.sendMessage(ADMIN_JID, { text: "No se encontraron usuarios en el estado venta terminada para eliminar." });
            }
        } catch (error) {
            console.error("Error al eliminar usuarios del estado VENTA_TERMINADA:", error);
            await whatsappSock.sendMessage(ADMIN_JID, { text: "ERROR: No se pudieron eliminar usuarios del estado venta terminada." });
        }
        return;
    }
}

function init(sock) {
    whatsappSock = sock;
    console.log("Cerebro initialized with WhatsApp sock.");

    // Iniciar el "Heartbeat" de humanización: se desconecta por 5s cada 60s.
    utility.startHumanizationHeartbeat(whatsappSock, utility.delay, 60, 5);

    setInterval(() => checkInactiveUsers(sock), 2 * 60 * 60 * 1000);

    whatsappSock.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type === "notify") {
            for (const msg of messages) {
                if (!msg.key.fromMe && msg.key.remoteJid !== "status@broadcast") {
                    const jid = jidNormalizedUser(msg.key.remoteJid);
                    // Detección de media y nota de voz
                    const isImage = msg.message?.imageMessage !== undefined || msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage !== undefined;
                    const isVoiceNote = msg.message?.audioMessage?.mimetype === 'audio/ogg; codecs=opus';
                    const isMedia = isImage || isVoiceNote;
                    let messageBody = msg.message?.extendedTextMessage?.text || msg.message?.conversation || "";
                    if (isImage && !messageBody) {
                        messageBody = msg.message?.imageMessage?.caption || "";
                    }

                    if (jid === ADMIN_JID) {
                        // Flujo de ADMINISTRADOR: Solo ejecuta handleAdminMessage y el loop continúa.
                        await handleAdminMessage(msg);
                    } else {
                        // Flujo de CLIENTE
                        // Esperar un tiempo aleatorio (2-5 segundos) para simular un retardo humano antes de leer
                        const randomDelay = Math.floor(Math.random() * (5000 - 2000 + 1)) + 2000;
                        await utility.delay(randomDelay);
                        // Marcar mensaje como leído (Cheques Azules)
                        await whatsappSock.readMessages([msg.key]);

                        // Lógica para responder a notas de voz (Voice Notes)
                        if (isVoiceNote && utility.getUserState(jid).state !== "INICIO") {
                            await sendVoiceNoteResponse(jid);
                            continue; // Salta el procesamiento normal del mensaje (handleMessage)
                        }
                        
                        await handleMessage(jid, messageBody, isMedia, msg);
                    }
                }
            }
        }
    });
}

async function checkInactiveUsers(sock) {
    console.log("Iniciando chequeo de usuarios inactivos...");
    const allStates = utility.getAllUserStates();
    const now = Date.now();
    const ONE_HOUR = 1 * 60 * 60 * 1000;
    const INACTIVITY_THRESHOLD = 1 * 60 * 1000;

    for (const jid in allStates) {
        const userState = allStates[jid];
        const { state, lastActivityTimestamp, reminderCount } = userState;

        if (state === "INICIO" || state === "VENTA_TERMINADA") {
            continue;
        }

        if (now - lastActivityTimestamp > INACTIVITY_THRESHOLD && reminderCount < 3) {
            const reminders = REMINDERS_POR_ESTADO[state];
            if (reminders && reminders[reminderCount]) {
                const reminderMessage = reminders[reminderCount];
                try {
                    await sock.sendMessage(jid, { text: reminderMessage });
                    utility.updateUserReminderInfo(jid, reminderCount + 1);
                    console.log(`Recordatorio ${reminderCount + 1} enviado a ${jid} en estado ${state}.`);
                } catch (error) {
                    console.error(`Error al enviar recordatorio a ${jid}:`, error);
                }
            }
        }
    }
    console.log("Chequeo de usuarios inactivos finalizado.");
}

module.exports = {
    init,
};
