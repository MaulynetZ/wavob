const REMINDERS_POR_ESTADO = {
    "INFORMACION_INICIAL": [
        "¡Hola de nuevo! 👋 Recuerda que nuestra oferta especial en el *LIBRO DIGITAL DE PERFUMERÍA* termina en *48 horas*. ¡No te quedes sin aprender a crear tus propios perfumes! Responde con el número que mejor te describa para continuar: \n\n1️⃣ Nunca he hecho perfumes \n2️⃣ Ya intenté hacer perfumes antes \n3️⃣ Me interesa pero tengo dudas 🤔",
        "¡Última oportunidad! ⏰ La promoción de *48 horas* para el *LIBRO DIGITAL* está a punto de expirar. Es tu momento de emprender en el mundo de la perfumería. ¿Cuál de estas opciones te describe mejor?\n\n1️⃣ Nunca he hecho perfumes \n2️⃣ Ya intenté hacer perfumes antes \n3️⃣ Me interesa pero tengo dudas 🤔",
        "¡No dejes pasar esta oferta única! ✨ El *LIBRO DIGITAL EN PDF* con todos los secretos de la perfumería está esperando por ti, y la promoción de *48 horas* está por finalizar. ¡Decídete hoy! Responde con el número que mejor te describa para seguir adelante:\n\n1️⃣ Nunca he hecho perfumes \n2️⃣ Ya intenté hacer perfumes antes \n3️⃣ Me interesa pero tengo dudas 🤔"
    ],
    "ESPERANDO_DETALLES_EBOOK": [
        "¡Hola! 👋 ¿Aún interesado en los detalles del *LIBRO DIGITAL DE PERFUMERÍA*? La promoción de *48 horas* está activa. Escribe *PDF* o *CURSO* para ver toda la información y aprovecharla.",
        "¡No te quedes con la duda! ⏳ Nuestra promoción de *48 horas* en el *LIBRO DIGITAL* es por tiempo limitado. Escribe *PDF* o *CURSO* para descubrir cómo puedes empezar tu negocio de perfumes hoy mismo.",
        "¡Es tu momento! ✨ La oferta de *48 horas* en el *LIBRO DIGITAL EN PDF* está a punto de terminar. Si quieres conocer todos los secretos de la perfumería, escribe *PDF* o *CURSO* ahora."
    ],
    "VIENDO_DETALLES_EBOOK": [
        "¡Hola! 😊 ¿Listo para transformar tu pasión en negocio? La promoción de *48 horas* para el *LIBRO DIGITAL DE PERFUMERÍA* te espera. Responde con el numero:\n\n1️⃣ Sí, quiero comprar \n2️⃣ Tengo una duda",
        "¡No esperes más! 🚀 La oferta especial de *48 horas* para el *LIBRO DIGITAL* está por finalizar. ¡Aprovecha esta oportunidad para empezar tu camino como perfumista! Responde con el numero:\n\n1️⃣ Sí, quiero comprar \n2️⃣ Tengo una duda",
        "¡Última llamada! 🔔 La promoción de *48 horas* en el *LIBRO DIGITAL EN PDF* es ahora o nunca. ¡No pierdas la oportunidad de aprender y emprender! Responde con el numero:\n\n1️⃣ Sí, quiero comprar \n2️⃣ Tengo una duda"
    ],
    "ESPERANDO_PAGO": [
        "¡Hola! 👋 Estamos esperando tu comprobante de pago para enviarte el *LIBRO DIGITAL EN PDF*. ¡Recuerda que la oferta es por *48 horas*! Envía tu imagen para finalizar la compra.",
        "¡No te olvides! ⏳ Tu *LIBRO DIGITAL* está listo para ser tuyo. La promoción de *48 horas* está activa. Envía tu comprobante de pago para recibirlo al instante.",
        "¡Casi lo tienes! ✨ Tu *LIBRO DIGITAL EN PDF* te espera. La oferta de *48 horas* está por terminar. Envía tu comprobante de pago ahora y empieza a crear tus perfumes."
    ],
    "ESPERANDO_VALIDACION_PAGO": [
        "¡Hola! 👋 Estamos validando tu pago del *LIBRO DIGITAL EN PDF*. Te recordamos que la promoción es por *48 horas*. Te avisaremos pronto. ¡Gracias por tu paciencia!",
        "¡Tu pago está en proceso! ⏳ Estamos verificando tu comprobante para el *LIBRO DIGITAL*. La oferta de *48 horas* sigue en pie. En breve tendrás noticias nuestras.",
        "¡Casi listo! ✨ Tu *LIBRO DIGITAL EN PDF* está a un paso. Estamos validando tu pago. La promoción de *48 horas* está por finalizar. ¡Gracias por tu compra!"
    ],
    "ASISTENTE_VIRTUAL": [
        "¡Hola! 👋 ¿Tienes más preguntas sobre el *LIBRO DIGITAL DE PERFUMERÍA*? La promoción de *48 horas* es una oportunidad única. Escribe *COMPRAR* si deseas ver los métodos de pago.",
        "¡No te quedes con dudas! ⏳ La oferta de *48 horas* en el *LIBRO DIGITAL* es por tiempo limitado. Si estás listo para comprar, escribe *COMPRAR* para ver los métodos de pago.",
        "¡Aclara tus dudas y aprovecha! ✨ La promoción de *48 horas* para el *LIBRO DIGITAL EN PDF* está por terminar. Si deseas proceder con la compra, escribe *COMPRAR*."
    ]
};

module.exports = {
    REMINDERS_POR_ESTADO
};
