const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const cerebro = require('./cerebro');

const startBot = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const { version, is } = await fetchLatestBaileysVersion();
    console.log(`using Baileys v${version.join('.')}`);

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false, // Deshabilitar la impresión automática de QR de Baileys
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        browser: ['Bot de WhatsApp', 'Chrome', '10.0.0'],
    });

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) {
            qrcode.generate(qr, { small: true }); // Generar y mostrar el QR en la terminal
            // console.log("QR RECEIVED:", qr); // Comentado para evitar imprimir la cadena QR raw
        }
        if (connection === 'close') {
            let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            if (reason === DisconnectReason.badAuthToken) {
                console.log('Bad Session File, Please Delete Session and Scan Again');
                startBot();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log('Connection closed, reconnecting....');
                startBot();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log('Connection Lost from Server, reconnecting...');
                startBot();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log('Connection Replaced, Another New Session Opened, Please Close Current Session First');
                startBot();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log('Device Logged Out, Please Delete Session and Scan Again.');
                startBot();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log('Restart Required, Restarting...');
                startBot();
            } else if (reason === DisconnectReason.timedOut) {
                console.log('Connection TimedOut, Reconnecting...');
                startBot();
            } else {
                sock.end(`Unknown DisconnectReason: ${reason}|${lastDisconnect.error}`);
            }
        } else if (connection === 'open') {
            console.log('Opened connection');
            cerebro.init(sock); // Pasar la instancia de sock a cerebro.js
        }
    });

    sock.ev.on('creds.update', saveCreds);
};

startBot();

