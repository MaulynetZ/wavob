const MENSAJE_1 = `👋 ¡Hola! Bienvenido/a 😊  
Soy el asistente del *Maestro Perfumista*.  
Estás a punto de descubrir cómo crear *perfumes profesionales desde casa*, con fórmulas exclusivas y fáciles de aplicar 💐✨`;

const MENSAJE_2 = `🔥 *¡PROMO DISPONIBLE SOLO POR 48 HORAS!* 🔥  

Obtén el 📘 *Libro Digital del Maestro Perfumista* + *2 BONOS EXCLUSIVOS:*  

🎁 *BONO 1:* Mas de 100 fórmulas para fabricar productos de limpieza.  
🧼 *BONO 2:* Libro digital jabones espumosos profesionales.  

✨ Todo el paquete por solo *$15.000 pesitos (único pago)*  
⏰ *Oferta válida solo por 48 horas.*`;

const MENSAJE_3 = `✨ ¿Qué deseas hacer ahora?  

👉 *Escribe y enviame el número de la opción que prefieras:*  

🟢 Envia el número 1️⃣ para *ver los métodos de pago 💸*  
🟢 Envia el número 2️⃣ para *hablar con un consultor 👩‍💼*`;

module.exports = { MENSAJE_1, MENSAJE_2, MENSAJE_3 };
